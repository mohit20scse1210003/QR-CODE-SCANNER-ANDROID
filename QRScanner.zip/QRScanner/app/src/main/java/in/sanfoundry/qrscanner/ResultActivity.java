package in.sanfoundry.qrscanner;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

public class ResultActivity extends AppCompatActivity {

    private AdView mAdView, mid_adView;
    String resulT, qr_format;
    TextView editText, formatText, webBtn;
    AdRequest adRequest, mid_adRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        webBtn = findViewById(R.id.openinweb);
//        mid_adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
        mAdView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        mid_adView = findViewById(R.id.middle_adView);
        mid_adRequest = new AdRequest.Builder().build();
        mid_adView.loadAd(mid_adRequest);

        Intent intent = getIntent();
        resulT = intent.getExtras().getString("result");
        qr_format = intent.getExtras().getString("qrformat");

        editText = findViewById(R.id.resulText);
        formatText = findViewById(R.id.qr_format);
        editText.setText(resulT);
        formatText.setText(qr_format);

        webBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!resulT.startsWith("http") && !resulT.startsWith("https://")){
                    resulT = "https://"+resulT;
                }
//                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(resulT));
                Intent browserIntent = new Intent(ResultActivity.this, WebviewActivity.class);
                browserIntent.putExtra("url", resulT);
                startActivity(browserIntent);
            }
        });

    }

    @Override
    public void onPause() {
        if (mAdView != null) {
            mAdView.pause();
        }
        if (mid_adView != null) {
            mid_adView.pause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mAdView != null) {
            mAdView.resume();
        }
        if (mid_adView != null){
            mid_adView.resume();
        }
    }

    @Override
    public void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }
        if (mid_adView != null){
            mid_adView.destroy();
        }
        super.onDestroy();
    }
}