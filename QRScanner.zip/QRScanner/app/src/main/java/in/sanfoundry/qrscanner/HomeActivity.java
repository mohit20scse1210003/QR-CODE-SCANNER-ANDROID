package in.sanfoundry.qrscanner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.OnSuccessListener;
import com.google.android.play.core.tasks.Task;

public class HomeActivity extends AppCompatActivity {

    CardView rect_cp, help_btn;
    CardView circle_cp, more_btn;
    ConstraintLayout updateLayout;
    LinearLayout scannerLayout;
    Button updateApp;
    private long backpressedtime;
    private Toast backtoast;
    public static int UPDATE_CODE = 2;
    AppUpdateManager appUpdateManager;
    private ReviewManager reviewManager;
    private AdView mAdView, mAdView1;
    AdRequest adRequest;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mAdView = findViewById(R.id.ad_view);
        mAdView1 = findViewById(R.id.ad_view1);
        adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        mAdView1.loadAd(adRequest);

        rect_cp = findViewById(R.id.rect_coupon);
        circle_cp = findViewById(R.id.circle_coupon);
        help_btn = findViewById(R.id.help);
        more_btn = findViewById(R.id.mini_app);

        rect_cp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, MainActivity.class));
            }
        });
        circle_cp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, CircleCpActivity.class));
//                Toast.makeText(HomeActivity.this, "Working on it. Please Wait...", Toast.LENGTH_SHORT).show();
            }
        });
        help_btn.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:developersbca@gmail.com")));
            }catch(ActivityNotFoundException e){
                Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
            }
        });
        more_btn.setOnClickListener(v ->{
            startActivity(new Intent(HomeActivity.this, CircleCpActivity.class));
        });

        scannerLayout = findViewById(R.id.App_content);
        updateLayout = findViewById(R.id.updateLayout);
        inAppUpdate();
        showRateApp();

        scannerLayout = findViewById(R.id.App_content);
        updateLayout = findViewById(R.id.updateLayout);

        updateLayout.setVisibility(View.GONE);
        scannerLayout.setVisibility(View.VISIBLE);

        updateApp = findViewById(R.id.updateBtn);
        updateApp.setOnClickListener(v -> inAppUpdate());

    }
//    Rating the app within App
    private void showRateApp() {
        reviewManager = ReviewManagerFactory.create(this);
        Task <ReviewInfo> request = reviewManager.requestReviewFlow();
        request.addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // Getting the ReviewInfo object
                ReviewInfo reviewInfo = task.getResult();

                Task <Void> flow = reviewManager.launchReviewFlow(this, reviewInfo);
                flow.addOnCompleteListener(task1 -> {

                });
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case (R.id.share_btn):
                Intent intentInvite = new Intent(Intent.ACTION_SEND);
                intentInvite.setType("text/plain");
                String body = "http://play.google.com/store/apps/details?id=in.sanfoundry.qrscanner";
                String subject = "HP COUPON SCANNER AND QR CODE SCANNER";
                intentInvite.putExtra(Intent.EXTRA_SUBJECT, subject);
                intentInvite.putExtra(Intent.EXTRA_TEXT, body);
                startActivity(Intent.createChooser(intentInvite, "Share using"));
                return true;
            case R.id.rate_btn:
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=in.sanfoundry.qrscanner")));
                }catch(ActivityNotFoundException e){
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=in.sanfoundry.qrscanner")));
                }
                return true;
            case (R.id.privacy_btn):
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://qtoa.ultimatefreehost.in/play_store/privacy/qrscanner-privacy.html")));
                }catch(ActivityNotFoundException e){
                    Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
                }
                return true;
            case (R.id.videoBtn):
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=FkFPfeEChCg")));
                }catch(ActivityNotFoundException e){
                    Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
                }
                return true;
            case (R.id.emailBtn):
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:developersbca@gmail.com")));
                }catch(ActivityNotFoundException e){
                    Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
                }
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    public void inAppUpdate() {
        appUpdateManager = AppUpdateManagerFactory.create(this);
        Task<AppUpdateInfo> task = appUpdateManager.getAppUpdateInfo();
        task.addOnSuccessListener(new OnSuccessListener<>() {
            @Override
            public void onSuccess(AppUpdateInfo appUpdateInfo) {
                if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                        && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                    try {
                        appUpdateManager.startUpdateFlowForResult(appUpdateInfo, AppUpdateType.IMMEDIATE, HomeActivity.this, UPDATE_CODE);
                    } catch (IntentSender.SendIntentException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        appUpdateManager.registerListener(listener);
    }

    InstallStateUpdatedListener listener = installState -> {
        if (installState.installStatus() == InstallStatus.DOWNLOADED){
            popUp();
        }
    };
    //update popup
    private void popUp() {
        @SuppressLint("ShowToast") Snackbar snackbar = Snackbar.make(
                findViewById(android.R.id.content),
                "App Update Almost Done",
                Snackbar.LENGTH_INDEFINITE
        );
        snackbar.setAction("reload", v -> appUpdateManager.completeUpdate());
        snackbar.setTextColor(Color.parseColor("#ff0000"));
        snackbar.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == UPDATE_CODE){
            if (resultCode == RESULT_OK){
                Toast.makeText(this, "Updated successful.", Toast.LENGTH_SHORT).show();
            }
            if (resultCode != RESULT_OK){
                updateLayout.setVisibility(View.VISIBLE);
                scannerLayout.setVisibility(View.GONE);
            }
        }
    }

        //    Double back to close the app
        @Override
        public void onBackPressed () {
            if (backpressedtime + 2000 > System.currentTimeMillis()) {
                super.onBackPressed();
                backtoast.cancel();
                return;
            } else {
                backtoast = Toast.makeText(this, "Press Back Again to Exit.", Toast.LENGTH_SHORT);
                backtoast.show();
            }
            backpressedtime = System.currentTimeMillis();
        }




}
