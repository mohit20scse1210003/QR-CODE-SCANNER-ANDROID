package in.sanfoundry.qrscanner;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.Settings;
import android.widget.Toast;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.zxing.Result;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.util.List;

public class CircleCpActivity extends AppCompatActivity {

    private CodeScanner mCodeScanner;
    private AdView nAdView;
    AdRequest adRequest;
    private int GPS_REQUEST_CODE = 1002;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_circle_cp);
        CodeScannerView scannerView = findViewById(R.id.scanner);

        nAdView = findViewById(R.id.ad_view1);
        adRequest = new AdRequest.Builder().build();
        nAdView.loadAd(adRequest);

        mCodeScanner = new CodeScanner(CircleCpActivity.this, scannerView);
        mCodeScanner.setZoom(10);
        mCodeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull final Result result) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        vibrate();
                        if ((result.getText().contains("taghash.co/"))) {

                            Intent i = new Intent(CircleCpActivity.this, WebViewActivity2.class); //change Activity for webview
                            i.putExtra("url", result.getText());
                            startActivity(i);
                            finish();
                        } else if (!(result.getText().contains("taghash.co/"))) {
                            Intent in = new Intent(CircleCpActivity.this, ResultActivity.class);
                            in.putExtra("result", result.getText());
                            in.putExtra("qrformat", result.getBarcodeFormat().toString());
                            startActivity(in);
                        }
                    }
                });
            }
        });
        scannerView.setOnClickListener(view -> mCodeScanner.startPreview());

        findViewById(R.id.manualScan).setOnClickListener(v -> {
            Intent i = new Intent(CircleCpActivity.this, ManualScanActivity.class); //change Activity ManualScan
            startActivity(i);
            finish();
        });


    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    protected void onResume() {
        if(nAdView != null){
            nAdView.resume();
        }
        super.onResume();
        checkCamera();
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void checkCamera() {
        PackageManager pm = this.getPackageManager();
        if (pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)) {
            requestCamera();
        } else {
            Toast.makeText(this, "Camera not found!", Toast.LENGTH_SHORT).show();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void requestCamera() {
        Dexter.withContext(CircleCpActivity.this)
                .withPermissions(
                        Manifest.permission.CAMERA,
                        Manifest.permission.ACCESS_FINE_LOCATION,
//                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {

                        if (multiplePermissionsReport.areAllPermissionsGranted()){

                            if (GPSEnable()){
                                mCodeScanner.startPreview();
                            }
                        }
//                        if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied()){
//                            Toast.makeText(MainActivity.this, "Allow all Permission to use app.", Toast.LENGTH_LONG).show();
//                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
//                            Uri uri = Uri.fromParts("package", getPackageName(), null);
//                            intent.setData(uri);
//                            startActivity(intent);
//                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                        permissionToken.continuePermissionRequest();
                    }
                }).check();

    }


    @Override
    protected void onPause() {
        mCodeScanner.releaseResources();
        if (nAdView != null) {
            nAdView.pause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (nAdView != null) {
            nAdView.destroy();
        }
        mCodeScanner.releaseResources();
        super.onDestroy();
    }

    private boolean GPSEnable(){
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        boolean providerEnable = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if (providerEnable){
            return true;
        }else{
            AlertDialog alertDialog = new AlertDialog.Builder(this)
                    .setTitle("GPS Permission")
                    .setMessage("Location is required to run this app. Please enable Location")
                    .setPositiveButton("Turn ON", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            startActivityForResult(intent, GPS_REQUEST_CODE);

                        }
                    }).setCancelable(false)
                    .show();
        }
        return false;
    }

    public void vibrate() {
        Vibrator vibrator = (Vibrator) this.getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(100);
    }
}