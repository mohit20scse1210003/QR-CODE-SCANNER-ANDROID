package in.sanfoundry.qrscanner;


import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.Objects;

public class WebviewActivity extends AppCompatActivity {

    WebView webView;
    String webUrl;
    ProgressBar progressBarWeb;
    RelativeLayout relativeLayout;
    Button btnNoConnection;
    private AdView mAdView, mAdView2;
    AdRequest adRequest;


    @SuppressLint("SetJavaScriptEnabled")
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Objects.requireNonNull(getSupportActionBar()).hide();
    /*
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN); //full screenView
    */

        setContentView(R.layout.activity_webview);
        // Initialize variables
        webView = findViewById(R.id.myWebView);
        progressBarWeb = findViewById(R.id.progressBar);
        btnNoConnection = findViewById(R.id.btnNoConnection);
        relativeLayout = findViewById(R.id.relativeLayout);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setGeolocationEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.getSettings().setDatabasePath(this.getFilesDir().getPath());
        webView.getSettings().getSaveFormData();
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setGeolocationDatabasePath( WebviewActivity.this.getFilesDir().getPath());

        Intent intent = getIntent();

        webUrl = intent.getExtras().getString("url");
//        webUrl = intent.getExtras().getString("url");
//        webUrl = webUrl.substring(28,41);
//        webUrl = "https://taghash.co/hppay/index1.php?qc="+webUrl;

        mAdView = findViewById(R.id.ad_view);
        mAdView2 = findViewById(R.id.ad_view2);
        adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        mAdView2.loadAd(adRequest);

        findViewById(R.id.closeBtn).setOnClickListener(v -> {
        startActivity(new Intent(WebviewActivity.this, MainActivity.class));
        finish();
        });

        if (savedInstanceState == null) {
            checkConnection();
        } else {
            webView.restoreState(savedInstanceState);
        }



        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                // swipeRefreshLayout.setRefreshing(false);
//                webView.loadUrl(url);
//                view.loadUrl("javascript:document.getElementByName("+"city"+").value = 6 ;");
//                view.loadUrl("javascript:var selectElement = document.getElementById('city');\n" +
//                        "\n" +
//                        "for (var age = 1; age <= 10; age++) {\n" +
//                        "  selectElement.add(new Option(age));\n" +
//                        "} ;");
                super.onPageFinished(view, url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                checkConnection();
                view.loadUrl(url);
                return true;
            }

        });


        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {

                progressBarWeb.setVisibility(View.VISIBLE);
                progressBarWeb.setProgress(newProgress);
                progressBarWeb.getProgressDrawable().setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_IN);
                if (newProgress == 100) {
                    progressBarWeb.setVisibility(View.GONE);
                }
                super.onProgressChanged(view, newProgress);
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(final String origin, final GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, true);
            }
        });

        btnNoConnection.setOnClickListener(v -> checkConnection());


        if(Build.VERSION.SDK_INT>= Build.VERSION_CODES.M){
            if(checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED){

                Toast.makeText(this, "Permission denied to WRITE_EXTERNAL_STORAGE", Toast.LENGTH_SHORT).show();
                String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                requestPermissions(permissions,1);
            }
        }

//handle downloading
        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {

                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimeType);
                String cookies = CookieManager.getInstance().getCookie(url);
                request.addRequestHeader("cookie",cookies);
                request.addRequestHeader("User-Agent",userAgent);
                request.setDescription("Downloading...");
                request.setTitle(URLUtil.guessFileName(url,contentDisposition,mimeType));
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,URLUtil.guessFileName(url, contentDisposition, mimeType));
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                dm.enqueue(request);
                Toast.makeText(getApplicationContext(),"Downloading File",Toast.LENGTH_SHORT).show();
            }
        });

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            checkConnection();
            webView.goBack();
        } else {
//            super.onBackPressed();
            startActivity(new Intent(WebviewActivity.this, MainActivity.class));
            finish();

        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkConnection() {
        ConnectivityManager connectivityManager = (ConnectivityManager)
                this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetworkInfo mobileNetwork = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

// check internet connection
        if (wifi.isConnected()) {
            webView.setVisibility(View.VISIBLE);
            relativeLayout.setVisibility(View.GONE);
            webView.loadUrl(webUrl);
        } else if (mobileNetwork.isConnected()) {
            webView.setVisibility(View.VISIBLE);
            relativeLayout.setVisibility(View.GONE);
            webView.loadUrl(webUrl);
        } else {
            webView.setVisibility(View.GONE);
            relativeLayout.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    public void onPause() {
        if (mAdView != null) {
            mAdView.pause();
        }
        if (mAdView2 != null) {
            mAdView2.pause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mAdView != null) {
            mAdView.resume();
        }
        if (mAdView2 != null) {
            mAdView2.resume();
        }
    }

    @Override
    public void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }
        if (mAdView2 != null){
            mAdView2.destroy();
        }
        super.onDestroy();
    }

}