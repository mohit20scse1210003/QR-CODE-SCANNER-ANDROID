package in.sanfoundry.qrscanner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class ManualScanActivity extends AppCompatActivity {

    EditText couponText;
    AppCompatButton submitbtn;
    AdRequest adRequest;
    private AdView mAdView, mAdView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual_scan);
        getSupportActionBar().hide();
        couponText = findViewById(R.id.couponCodeText);
        submitbtn = findViewById(R.id.submitBtn);

        mAdView = findViewById(R.id.ad_view);
        mAdView1 = findViewById(R.id.ad_view1);
        adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        mAdView1.loadAd(adRequest);

        submitbtn.setOnClickListener(v -> validateCoupon());

    }

    private void validateCoupon() {
        if ((couponText.length() < 13) || (couponText.length() > 13)){
            couponText.setError("please enter 13 digit code");
        }else{
            validationdone();
        }
    }

    private void validationdone() {

        Intent i = new Intent(this, WebviewActivity.class);
        i.putExtra("url", "https://taghash.co/hppay/index.php?qc="+couponText.getText());
        startActivity(i);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(mAdView != null){
            mAdView.resume();
        }
    }

    @Override
    protected void onPause() {
        if (mAdView != null) {
            mAdView.pause();
        }
        super.onPause();
    }

    @Override
    public void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(this, HomeActivity.class));
        finish();
    }
}